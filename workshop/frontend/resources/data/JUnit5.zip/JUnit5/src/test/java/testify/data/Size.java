package testify.data;

public enum Size {
    xs, s, m, l, xl
}
