package testify.data;

public enum Size {
    XS, S, M, L, XL
}
