package testify.data;

public enum Color {
    white, black, red, green, blue
}
