package testify.data;

public enum Delivery {
    standard, express
}
