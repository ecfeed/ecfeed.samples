package testify.data;

public enum Payment {
    visa, mastercard, bank_transfer, cash_on_delivery
}
