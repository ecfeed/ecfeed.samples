package testify.data;

public enum Payment {
    VISA, MASTERCARD, bank_transfer, cash_on_delivery
}
