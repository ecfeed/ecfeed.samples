package testify.data;

public enum Country {
    poland, norway, other
}
