package testify.data;

public enum Country {
    Poland, Norway, other
}
