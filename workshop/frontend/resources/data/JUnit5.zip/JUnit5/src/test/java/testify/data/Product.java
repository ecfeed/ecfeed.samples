package testify.data;

public enum Product {
    t_shirt, hoodie
}
